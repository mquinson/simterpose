#ifndef WRAP_H
#define WRAP_H

#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <pthread.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/socket.h>

void LogWrap(char *mess);

void DLSym_fonctions();

#endif
