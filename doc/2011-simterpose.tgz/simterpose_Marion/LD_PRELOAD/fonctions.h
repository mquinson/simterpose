#ifndef FONCTIONS_H
#define FONCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>

typedef int (*SOCKET_ORIG)(int domain, int type, int protocol);
typedef int (*CLOSE_ORIG)(int fd);
typedef ssize_t (*SEND_ORIG)(int s, const void *msg, size_t len, int flags);
typedef ssize_t (*SENDTO_ORIG)(int s, const void *msg, size_t len, int flags, const struct sockaddr *to, socklen_t tolen);
typedef ssize_t (*RECV_ORIG)(int s, void *buf, size_t len, int flags);
typedef ssize_t (*RECVFROM_ORIG)(int s, void *buf, size_t len, int flags, struct sockaddr *from, socklen_t *fromlen);
typedef int (*BIND_ORIG)(int sockfd, const struct sockaddr *my_addr, socklen_t addrlen);
typedef int (*CONNECT_ORIG)(int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen);
typedef int (*LISTEN_ORIG)(int s, int backlog);
typedef int (*ACCEPT_ORIG)(int sock, struct sockaddr *adresse, socklen_t *longueur);
typedef int (*SELECT_ORIG)(int n, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *timeout); 
typedef ssize_t (*READ_ORIG)(int fildes, void *buf, size_t nbyte);
typedef int (*WRITE_ORIG)(int handle, const void *buffer, size_t nbyte);

typedef int (*PTHREAD_CREATE_ORIG)(pthread_t* thread,const pthread_attr_t* attr, void*(*start_routine)(void*), void* arg);
typedef int (*PTHREAD_JOIN_ORIG)(pthread_t thread, void **thread_return);
typedef void __attribute__((noreturn)) (*PTHREAD_EXIT_ORIG)(void *retval);

typedef int (*DUP_ORIG)(int oldfd);
typedef int (*DUP2_ORIG)(int oldfd, int newfd);
typedef pid_t (*FORK_ORIG)(void);

typedef int (*SETUID_ORIG)(uid_t uid);
typedef int (*SYSTEM_ORIG)(const char * string);  



SOCKET_ORIG socket_orig;
CLOSE_ORIG close_orig;
LISTEN_ORIG listen_orig;
ACCEPT_ORIG accept_orig;
BIND_ORIG bind_orig;
SEND_ORIG send_orig;
SENDTO_ORIG sendto_orig;
RECV_ORIG recv_orig;
RECVFROM_ORIG recvfrom_orig;
CONNECT_ORIG connect_orig;
SELECT_ORIG select_orig;
READ_ORIG read_orig;
WRITE_ORIG write_orig;

PTHREAD_CREATE_ORIG pthread_create_orig;
PTHREAD_JOIN_ORIG pthread_join_orig;
PTHREAD_EXIT_ORIG pthread_exit_orig;

DUP_ORIG dup_orig;
DUP2_ORIG dup2_orig;
FORK_ORIG fork_orig;

SETUID_ORIG setuid_orig;
SYSTEM_ORIG system_orig;

#endif
