#define RTLD_NEXT ((void *) -1l)

char *error_msg;

/* On ecrit dans un fichier l'ensemble des fonctions wrappees */
void LogWrap(char *mess){
  FILE *file_log2=fopen("./LD_PRELOAD/file_log2","a");
  fprintf(file_log2,"%s",mess);
  fclose(file_log2);
}

/* La fonction dlsym() prend un descripteur de bibliotheque et un nom de symbole et renvoie l'adresse ou ce symbole a ete charge */
void DLSym_fonctions(){
	
  dup_orig=dlsym(RTLD_NEXT,"dup");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym dup !\n");

}

/* On reecrit la fonction dup en ajoutant des messages d'informations et en appelant l'originale */
int dup(int oldfd){
  DLSym_fonctions();
  LogWrap("appel dup()\n");
  int ret=dup_orig(oldfd);
  LogWrap("appel dup() terminé\n");
  return ret;
}


