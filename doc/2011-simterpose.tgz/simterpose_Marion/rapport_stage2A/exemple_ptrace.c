#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <linux/user.h>
#include <sys/syscall.h>

int main(){   
	pid_t child;
  long orig_eax, eax;
  long params[3];
  int status;
  int insyscall = 0;
  struct user_regs_struct regs;
  child = fork();
  if(child == 0) {
      ptrace(PTRACE_TRACEME, 0, NULL, NULL);
      execl("/bin/ls", "ls", NULL);
  }else{
    while(1) {
      wait(&status);
      if(WIFEXITED(status))
          break;
      orig_eax = ptrace(PTRACE_PEEKUSER, child, 4 * ORIG_EAX, NULL); // contient le numero de l'appel systeme intercepte
      if(orig_eax == SYS_dup) {
      	if(insyscall == 0){ // on est en entree de l'appel 
          insyscall = 1;
          ptrace(PTRACE_GETREGS, child, NULL, &regs); // on consulte les registres pour obtenir les parametres de l'appel
          printf("Dup called with %ld\n",regs.ebx);
        }else{ // on sort de l'appel
          eax = ptrace(PTRACE_PEEKUSER,child, 4 * EAX,NULL); // contient la valeur retour de l'appel
          printf("Dup returned with %ld\n", eax);
          insyscall = 0;
        }
      }
      ptrace(PTRACE_SYSCALL, child,NULL, NULL); // on fait repartir le fils
    }
  }
  return 0;
}

