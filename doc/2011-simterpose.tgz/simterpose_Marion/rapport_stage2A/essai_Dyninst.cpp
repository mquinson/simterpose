#include <stdio.h>
#include <fcntl.h>
#include "BPatch.h"
#include "BPatch_process.h"
#include "BPatch_function.h"
#include "BPatch_Vector.h"
#include "BPatch_thread.h"

void usage(){
  fprintf(stderr,"Usage : essai <filename> <args>\n");
}

BPatch bpatch;

int main(int argc, char *argv[]){

  if(argc<2){
    usage();
    exit(1);
  }
  fprintf(stderr,"Attaching to process ... \n");
  BPatch_process *appProc = bpatch.processCreate(argv[1],NULL);
  if(!appProc){
    fprintf(stderr, "echec create process\n");
    return -1;
  }

  BPatch_image *appImage;
  BPatch_Vector<BPatch_function *> dupFuncs;
  fprintf(stderr, "Opening the programm image ...\n");
  appImage = appProc->getImage();
  appImage->findFunction("dup",dupFuncs);

  if(dupFuncs.size() == 0){
    fprintf(stderr, "ERROR : Unable to find function for dup()\n");
    return 1;
  }else{
    printf("dup trouve !\n");
  }
}
