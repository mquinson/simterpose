#!/bin/bash

../applications/server &
sleep 3
../applications/client 
