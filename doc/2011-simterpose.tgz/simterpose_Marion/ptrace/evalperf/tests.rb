#!/usr/bin/ruby -w

puts "Without ptrace"
[1, 10, 100, 1000, 10000, 50000, 100000, 200000, 500000].each do |i|
ts = Time::now
size=1000000/i
system("/bin/dd if=/dev/zero of=/dev/zero bs=#{size} count=#{i} >/dev/null 2>&1")
te = Time::now
puts "#{i} #{size} #{te - ts}"
end

puts "With ptrace"
[1, 10, 100, 1000, 10000, 50000, 100000, 200000, 500000].each do |i|
ts = Time::now
size=1000000/i
system("./p1 /bin/dd if=/dev/zero of=/dev/zero bs=#{size} count=#{i} >/dev/null 2>&1")
te = Time::now
puts "#{i} #{size} #{te - ts}"
end
