#include "insert_trace.h"

char buftrace[512];
long long int times_syscall[3];
long long int diff_time=0;
long long int diff_cpu=0;


char * trace_header(int simgrid, int pid, char *type, char * syscall) {
  
  if (ask_time(pid, times_syscall)) {
    perror("Error ask_time");
    exit(1);
  } else {
    struct timeval tv;
    struct timezone tz;
    struct tm *t;
    gettimeofday(&tv, &tz);
    t=localtime(&tv.tv_sec);

    long long int last_time = get_last_walltime(pid);
    
    if (last_time != -1)
      diff_time = times_syscall[0] - last_time;
    long long int last_cpu = get_last_cputime(pid);

    diff_cpu=(times_syscall[1] + times_syscall[2]) - last_cpu;

    update_walltime_procs(pid,times_syscall[0]);
    update_cputime_procs(pid,times_syscall[1]+times_syscall[2]);

    if(simgrid){
	sprintf(buftrace, "%8d %12s", pid, syscall);
    }else{
      sprintf(buftrace, "%02u:%02u:%02u:%6d %8d %10lld %10lld %10lld %10lld %5s %12s", t->tm_hour,t->tm_min,t->tm_sec,(int)tv.tv_usec,pid, times_syscall[0],times_syscall[1]+times_syscall[2],diff_time,diff_cpu,type,syscall);
    }
    return buftrace;
  }
}

void insert_trace_comm(int simgrid, FILE *trace, pid_t pid, int sockfd , char *syscall, char *type, ...) {
 
  va_list ap;
  va_start(ap, type);
  int res = va_arg(ap,int);
  char *trace_param = va_arg(ap,char *);

  if (get_domain_sockfd(pid,sockfd) == 2) { // PF_INET -> local and remote addr:port known
    struct infos_socket is;
    get_infos_socket(pid,sockfd,&is);
    if(simgrid){
      if(strcmp(type,"out") == 0){
	fprintf(trace,"%s %8d %10d %10lld %10lld %10lld %10lld", trace_header(simgrid, pid, type, syscall), get_pid_socket_dest(&is), res, times_syscall[0],times_syscall[1]+times_syscall[2],diff_time,diff_cpu);
	fprintf(trace," %15s:%5d %15s:%5d", is.ip_local,is.port_local,is.ip_remote,is.port_remote);
      }
    }else{
      fprintf(trace,"%s %15s:%5d %15s:%5d", trace_header(simgrid, pid, type, syscall), is.ip_local,is.port_local,is.ip_remote,is.port_remote);
      fprintf(trace," %8d",get_pid_socket_dest(&is));
    }
  } else{
    if(simgrid){
      if(strcmp(type,"out") == 0)
	fprintf(trace,"%s %10d %52s", trace_header(simgrid,pid, type, syscall), res, " ");
    }else
      fprintf(trace,"%s %52s", trace_header(simgrid,pid, type, syscall)," ");
  }

  if(simgrid){
    if(strcmp(type,"out") == 0)
      fprintf(trace, " \t%s\n", trace_param);
  }else{
    if(strcmp(type,"out") == 0)
      fprintf(trace, " %10d \t%s\n", res, trace_param);
    else
      fprintf(trace, "\n");
  }
    
  va_end(ap);


}

void insert_trace_fork_exit(int simgrid, FILE *trace,pid_t pid, char *syscall, int res) {

  if(simgrid)
    fprintf(trace,"%s %10s %8d\n", trace_header(simgrid, pid,"out",syscall), " ", res);
  else
    fprintf(trace,"%s %52s %10d\n", trace_header(simgrid, pid, " ",syscall)," ",res);

}
