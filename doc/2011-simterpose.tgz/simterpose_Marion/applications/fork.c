#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main(){

  /*pid_t pid;
  if((pid=fork())){ 
    printf("Pere du fork, fils = %d \n",pid);
  }else{
    char buf[10];
    printf("%d - Fils du fork\n",pid);
    read(10,buf,10);
    dup(0);

    }*/
  return 0;
}
