#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

const char * NomJourSemaine[] = {"Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"};

const char * NomMois[] = {"janvier", "fevrier", "mars"     , "avril"  , "mai"     , "juin"    ,
                          "juillet", "aout"   , "septembre", "octobre", "novembre", "decembre"};


int main(int argc, char *argv[]){

  time_t timestamp;
  struct tm * t;
  
  timestamp = time(NULL);
  t = localtime(&timestamp);
  

  FILE *f=fopen("file_log","a");
  fprintf(f,"---------- le %02u %s %04u, à %02uh %02umin %02usec -----------\n", t->tm_mday, NomMois[t->tm_mon], 1900 + t->tm_year, t->tm_hour, t->tm_min, t->tm_sec);
  fclose(f);

  if(argc != 2){
    printf("Il faut un executable en argument !\n");
    return 1;
  }

  execl(argv[1],argv[1],(char *)0);
  
}
