/* Syscalls that we might want to intercept
   List from strace's source code */

	{ 0,	0,	sys_restart_syscall,	"restart_syscall" }, /* 0 */
	{ 0,	TP,	sys_fork,		"fork", SYS_fork }, /* 2 */
	{ 3,	TD,	sys_read,		"read", SYS_read }, /* 3 */
	{ 3,	TD,	sys_write,		"write", SYS_write }, /* 4 */
	{ 1,	TD,	sys_close,		"close"		}, /* 6 */
	{ 1,	TD,	sys_dup,		"dup"		}, /* 41 */
	{ 3,	TD,	sys_ioctl,		"ioctl"		}, /* 54 */
	{ 3,	TD,	sys_fcntl,		"fcntl"		}, /* 55 */
	{ 2,	TD,	sys_dup2,		"dup2"		}, /* 63 */
	{ 1,	TD,	sys_oldselect,		"oldselect"	}, /* 82 */
	{ 2,	TD,	sys_socketcall,		"socketcall", SYS_socketcall }, /* 102 */
	{ 5,	TP,	sys_clone,		"clone", SYS_clone }, /* 120 */
	{ 5,	TD,	sys_select,		"select"	}, /* 142 */
	{ 3,	TD,	sys_readv,		"readv", SYS_readv }, /* 145 */
	{ 3,	TD,	sys_writev,		"writev", SYS_writev }, /* 146 */
	{ 3,	TD,	sys_poll,		"poll"		}, /* 168 */

	{ 5,	TD,	sys_pread,		"pread64", SYS_read }, /* 180 */
	{ 5,	TD,	sys_pwrite,		"pwrite64", SYS_write }, /* 181 */
	{ 4,	TD,	sys_sendfile,		"sendfile"	}, /* 187 */
	{ 4,	TD,	sys_sendfile64,		"sendfile64"	}, /* 239 */
	{ 8,	0,	printargs,		"socket_subcall"}, /* 400 */
	{ 3,	TN,	sys_socket,		"socket"	}, /* 401 */
	{ 3,	TN,	sys_bind,		"bind"		}, /* 402 */
	{ 3,	TN,	sys_connect,		"connect"	}, /* 403 */
	{ 2,	TN,	sys_listen,		"listen"	}, /* 404 */
	{ 3,	TN,	sys_accept,		"accept"	}, /* 405 */
	{ 3,	TN,	sys_getsockname,	"getsockname"	}, /* 406 */
	{ 3,	TN,	sys_getpeername,	"getpeername"	}, /* 407 */
	{ 4,	TN,	sys_socketpair,		"socketpair"	}, /* 408 */
	{ 4,	TN,	sys_send,		"send", SYS_sub_send }, /* 409 */
	{ 4,	TN,	sys_recv,		"recv", SYS_sub_recv }, /* 410 */
	{ 6,	TN,	sys_sendto,		"sendto", SYS_sub_sendto }, /* 411 */
	{ 6,	TN,	sys_recvfrom,		"recvfrom", SYS_sub_recvfrom }, /* 412 */
	{ 2,	TN,	sys_shutdown,		"shutdown"	}, /* 413 */
	{ 5,	TN,	sys_setsockopt,		"setsockopt"	}, /* 414 */
	{ 5,	TN,	sys_getsockopt,		"getsockopt"	}, /* 415 */
	{ 5,	TN,	sys_sendmsg,		"sendmsg"	}, /* 416 */
	{ 5,	TN,	sys_recvmsg,		"recvmsg"	}, /* 417 */
