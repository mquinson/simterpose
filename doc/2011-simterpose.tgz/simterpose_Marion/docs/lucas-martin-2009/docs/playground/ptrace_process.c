#include <sys/ptrace.h>
#include <signal.h>
#include <sys/user.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>

/* Trigger a getpid syscall manually (glibc will optimize it away
 * if we call getpid() ) */
int my_getpid()
{
	int pid;
	__asm__(
                "movl $20, %%eax    \n"
		"int $0x80         \n"
        :"=rax"(pid));
	printf("my_getpid: %d\n", pid);
        return pid;
}

int main(int argc, char** argv)
{

	int  status = 0, pid, r;
	int insyscall;
	struct user_regs_struct uregs;
	if ((pid=fork())==0) {
		/* Traced process */
		printf("pid = %d, ppid = %d\n", getpid(), getppid());
		
	printf("Affichage du temps ");
	struct timeval tv;
	gettimeofday(&tv, NULL); 
	printf("%ld\n",tv.tv_usec);
		if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1)
		{
			perror("ptrace(child):");
			exit(1);
		}
		kill(getpid(), SIGINT); /* Trigger an interrupt, so
					   we can PTRACE_SYSCALL */
		r = my_getpid();
		printf("%d\n", getpid());
		exit(0);
		//execvp(argv[1], argv+1);
	} else {
		/* Tracer process */
		wait(&status);
		ptrace(PTRACE_SYSCALL, pid, 0, 0);
		insyscall = 0;
		while(1)
	       	{
			wait(&status);
			if (WIFEXITED(status))
			{
				printf("child over\n");
				exit(0);
			}
			if (insyscall)
			{
				ptrace(PTRACE_GETREGS, pid, 0, &uregs);
				//this should print 20, syscall number of getpid
				printf("syscall nr: %lu\n", uregs.orig_rax);
				printf("syscall res: %lu\n", uregs.rax);
			}
			insyscall = !insyscall;
			ptrace(PTRACE_SYSCALL, pid, 0, 0);
		}
	}
}

