#include <sys/ptrace.h>
#include <signal.h>
#include <sys/user.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{

	int  status = 0, pid;
	int insyscall;
	struct user_regs_struct uregs;
	if ((pid=fork())==0) {
		/* Traced process */
		printf("pid = %d, ppid = %d\n", getpid(), getppid());
		if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1)
		{
			perror("ptrace(child):");
			exit(1);
		}
		execvp(argv[1], argv+1);
	} else {
		/* Tracer process */
		wait(&status);
		ptrace(PTRACE_SYSCALL, pid, 0, 0);
		insyscall = 0;
		while(1)
	       	{
			wait(&status);
			if (WIFEXITED(status))
			{
				printf("child over\n");
				exit(0);
			}
			if (insyscall)
			{
				ptrace(PTRACE_GETREGS, pid, 0, &uregs);
				//this should print 20, syscall number of getpid
				printf("syscall nr: %lu\n", uregs.orig_rax);
				printf("syscall res: %lu\n", uregs.rax);
			}
			insyscall = !insyscall;
			ptrace(PTRACE_SYSCALL, pid, 0, 0);
		}
	}
	return 0;
}

