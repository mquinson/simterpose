/*
 * preload.h: what's needed to mediate applications through LD_PRELOAD
 *
 * Copyright (C) 2009 simterpose team. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package.
 */

#ifndef _SIMTERPOSE_PRELOAD_H_
#define _SIMTERPOSE_PRELOAD_H_

#include <stdio.h>
#include <msg/msg.h>

int preload_launch_child(int argc, char* argv[]);

typedef struct {
	char *name;
	int realpid;
	int from,to;

	m_process_t simdata;
} s_child_t,*child_t;

typedef enum {
	e_char=0,e_int=1,e_double=2
} e_kind_t;

static const char *kind_name(e_kind_t i) {
	switch(i){
	case e_char: return "char";
	case e_int: return "int";
	case e_double: return "double";
	}

	THROW1(0,0,"Asked unknown kind %d",i);
}


void child_discuss(child_t child);


typedef enum {
	e_socket_pre, e_socket_post
} syscall_kind_t;

extern const char * _gras_procname; /* change my name in the logs */

#endif /* _SIMTERPOSE_PRELOAD_H_ */
