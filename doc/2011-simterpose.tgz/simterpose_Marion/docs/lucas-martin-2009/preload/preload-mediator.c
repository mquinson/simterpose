/*
 * preload-mediator.c: follow a child and mediate (spy) its actions
 *
 * Copyright (C) 2009 simterpose team. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package.
 */

#include <stdio.h>
#include <unistd.h>
#include <xbt.h>
#include <xbt/strbuff.h> /* FIXME: missing from v3.3, kill afterward */

#include "preload.h"

XBT_LOG_EXTERNAL_CATEGORY(simterpose);
XBT_LOG_NEW_DEFAULT_SUBCATEGORY(networking, simterpose, "dialog with child");

xbt_dynar_t childs = NULL;

static void myread(int fd, void*ptr, int size) {
   int res = read(fd,ptr,size);
   xbt_assert0(res !=0,"Broken pipe (read returned 0)");
}  

void child_get(child_t child, const char*fmt,...) _XBT_GNUC_SCANF(2,3);
void child_get(child_t child, const char*fmt,...) {
	int *arg_i;
	double *arg_d;
	char kind;

	const char *p=fmt;
	va_list ap;
	va_start(ap, fmt);

	while (*p) {
		xbt_assert2(*p=='%',"Invalid char in format (%s): expected %%, got %c",fmt,*p);
		p++;
	   myread(child->from,&kind,sizeof(char));
		switch (*p) {
		case 'd':
			xbt_assert1(kind == e_int,"Got %s from child, was expecting int",kind_name(kind));
			arg_i = va_arg(ap, int*);
			myread(child->from,arg_i,sizeof(int));
			fprintf(stderr,"f: got int %d\n",*arg_i);
			break;
		case 'f':
			p++;
			xbt_assert2(*p=='f',"Invalid char in format (%s): expected %%lf, got %%l%c",fmt,*p);
			xbt_assert1(kind == e_double,"Got %s from child, was expecting double",kind_name(kind));
			arg_d = va_arg(ap, double*);
			fprintf(stderr,"read from %d\n",child->from);
			myread(child->from,arg_d,sizeof(double));
			break;
		default:
			xbt_die(bprintf("%s:%d: unimplemented format: %c",__FILE__,__LINE__,*p));
		}
		p++;
	}
	va_end(ap);
}

void child_push(child_t child, const char*fmt,...) _XBT_GNUC_SCANF(2,3);
void child_push(child_t child, const char*fmt,...) {
	int *arg_i;
	double *arg_d;
	char kind;

	const char *p=fmt;
	va_list ap;
	va_start(ap, fmt);

	while (*p) {
		xbt_assert2(*p=='%',"Invalid char in format (%s): expected %%, got %c",fmt,*p);
		p++;
		switch (*p) {
		case 'd':
			kind = e_int;
			arg_i = va_arg(ap, int*);
			fprintf(stderr,"f: send %s %d onto %d\n",kind_name(kind),*arg_i,child->to);
			write(child->to,&kind,sizeof(char));
			write(child->to,arg_i,sizeof(int));
			break;
		case 'l':
			p++;
			xbt_assert2(*p=='f',"Invalid char in format (%s): expected %%lf, got %%l%c",fmt,*p);
			kind = e_double;
			write(child->to,&kind,sizeof(char));
			write(child->to,p,sizeof(char));
			arg_d = va_arg(ap, double*);
			fprintf(stderr,"f: send %s %lf onto %d\n",kind_name(kind),*arg_d,child->to);
			write(child->from,arg_d,sizeof(double));
			break;
		default:
			xbt_die(bprintf("unimplemented format: %c",*p));
		}
		p++;
	}
	va_end(ap);
}
static void child_sleep(child_t child, double delay) {
	INFO1("Let kid sleep(%lf)",delay);
	child_push(child,"%lf",&delay);
}
void child_discuss(child_t child) {
	/* register my child so that it gets killed on need */
	int rank;
	if (!childs)
		childs = xbt_dynar_new(sizeof(child_t),NULL);
	rank =xbt_dynar_length(childs);
	xbt_dynar_push(childs, &child);


	/* discuss with it */
	while (1) {
		int kind;
		child_get(child,"%d",&kind);
		switch (kind) {
		case e_socket_pre: {
			int domain, type, protocol;
			child_get(child,"%d%d%d",&domain,&type,&protocol);
			INFO4("%s got PRE socket(%d,%d,%d)",child->name,domain,type,protocol);

			INFO4("%s snd PRE socket(%d,%d,%d)",child->name,domain,type,protocol);
			child_push(child,"%d%d%d",&domain,&type,&protocol);

			child_sleep(child,0);
			INFO1("%s slept 0",child->name);
			break;
		}
		case e_socket_post: {
			int res;
			child_get(child,"%d",&res);
			INFO2("%s POST socket(...) returned %d",child->name,res);
			child_push(child,"%d",&res);

			child_sleep(child,0);
			break;
		}

		}
	}
	/* remove my child without changing other's rank */
	child = NULL;
	xbt_dynar_set(childs,rank, &child);
}
