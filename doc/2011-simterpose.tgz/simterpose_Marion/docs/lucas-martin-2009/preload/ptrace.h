/*
 * ptrace.h: what's needed from simulator POV to follow a child with ptrace
 *
 * Copyright (C) 2009 simterpose team. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package.
 */

#ifndef _SIMTERPOSE_PTRACE_H_
#define _SIMTERPOSE_PTRACE_H_

#include <stdio.h>
#include <msg/msg.h>

int ptrace_launch_child(int argc, char* argv[]);

#endif /* _SIMTERPOSE_SIMULATOR_H_ */
