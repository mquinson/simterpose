/*
 * overloading.c: mechanism of intercepting the library calls of interest using LD_PRELOAD
 *
 * Copyright (C) 2009 simterpose team. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package.
 */

/* please gime the RTLD_NEXT symbol yourself */
#define _GNU_SOURCE
#include <stdio.h>
#include <dlfcn.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <errno.h>

#include "xbt.h"
#include "xbt/strbuff.h" /* FIXME: killme. Was missing from xbt.h 3.3 */
#include "xbt/xbt_os_time.h"
#include "preload.h"

#define DECLARE_OVERLOADED(ret,name,...) ret (*raw_##name)(__VA_ARGS__)

DECLARE_OVERLOADED(int,     socket,   int domain, int type, int protocol);
DECLARE_OVERLOADED(int,     bind,     int sockfd, const struct sockaddr *addr, socklen_t addrlen);
DECLARE_OVERLOADED(int,     accept,   int sockfd, struct sockaddr *addr, socklen_t *addrlen);

DECLARE_OVERLOADED(int,     close,    int sock);

DECLARE_OVERLOADED(ssize_t, read,     int, void *, size_t);
DECLARE_OVERLOADED(ssize_t, recv,     int, void *, size_t, int);

DECLARE_OVERLOADED(ssize_t, write,  int, const void *, size_t);
DECLARE_OVERLOADED(ssize_t, send,   int, const void *, size_t, int);

//DECLARE_OVERLOADED(int,     select, (int, fd_set *, fd_set *, fd_set *, struct timeval *));
//DECLARE_OVERLOADED(int,     poll,   (struct pollfd *, int, int));

DECLARE_OVERLOADED(int, dup,    int);
DECLARE_OVERLOADED(int, dup2,   int, int);

#include "xbt.h"
XBT_LOG_NEW_DEFAULT_CATEGORY(simterpose_inter,"Emulator intercepter messages");

#define INIT_INTERPOSER(name)  do {                   \
	if ((raw_##name = dlsym(dh, #name)) == NULL)      \
	xbt_die("Failed to get " #name "() address");     \
} while (0)


static void overloading_exit(void) {
	INFO0("Exiting");
}
static int initialized = 0;
static int initializing = 0;
static XBT_INLINE void simterpose_init(void) {
	void *dh;

	if (initialized || initializing)
		return;
	initializing = 1;

	_gras_procname = "overloading";

	atexit(&overloading_exit);

#ifndef DLOPEN_REQUIRED
	dh = (void *) -1L;
#else
	if ((dh = dlopen(DLOPENLIBC, RTLD_LAZY)) == NULL)
		errx(1, "[trickle] Failed to open libc");
#endif /* DLOPEN */

	INIT_INTERPOSER(socket);
	INIT_INTERPOSER(bind);
	INIT_INTERPOSER(accept);
	INIT_INTERPOSER(close);
	INIT_INTERPOSER(read);
	INIT_INTERPOSER(recv);
	INIT_INTERPOSER(write);
	INIT_INTERPOSER(send);
	INIT_INTERPOSER(accept);
	INIT_INTERPOSER(dup);
	INIT_INTERPOSER(dup2);

	initialized = 1;
}

/***********************************************
 * functions to speak with simulator           *
 ***********************************************/


/****************** Communication with father **********************/
/* both next values are hardcoded in simterpose-runner.c too */
const int father_out = 20; /* fd from my father */
const int father_in  = 21; /* fd to my father */

static void XBT_INLINE mywrite(e_kind_t k,void*ptr) {
	int todo;
	char kind = (char)k;
	todo = sizeof(char);
	int done = 0;
	while (todo!=done) {
		int got = (*raw_write)(father_in,((char*)&kind)+done,todo-done);
		xbt_assert2(got>0,"Error while writing (got %d): %s",got,strerror(errno));
		done+=got;
	}

	switch(k) {
	case e_char:
		fprintf(stderr,"c: send char %c\n",*(char*)ptr);
		todo = sizeof(char);
		break;
	case e_int:
		fprintf(stderr,"c: send int %d\n",*(int*)ptr);
		todo = sizeof(int);
		break;
	case e_double:
		fprintf(stderr,"c: send double %lf\n",*(double*)ptr);
		todo = sizeof(double);
		break;
	}

	done = 0;
	while (todo!=done) {
		int got = (*raw_write)(father_in,((char*)ptr)+done,todo-done);
		xbt_assert2(got>0,"Error while writing (got %d): %s",got,strerror(errno));
		done+=got;
	}
}

static void XBT_INLINE myread(e_kind_t k,void*ptr) {
	char kind = (char)k;
	int todo=sizeof(char);
	int done = 0;
	while (todo!=done) {
		int got = (*raw_read)(father_out,((char*)&kind)+done,todo-done);
		xbt_assert0(got!=0,"Unexpected end of transmission");
		xbt_assert2(got>0,"Error while reading (got %d): %s",got,strerror(errno));
		done+=got;
	}
	xbt_assert2(k==kind,"Got %s expected %s",kind_name(kind),kind_name(k));

	switch(k) {
	case e_char:
		fprintf(stderr,"child: recv c\n");
		todo = sizeof(char);
		break;
	case e_int:
		fprintf(stderr,"child: recv d\n");
		todo = sizeof(int);
		break;
	case e_double:
		fprintf(stderr,"child: recv f\n");
		todo = sizeof(double);
		break;
	}

	done = 0;
	while (todo!=done) {
		int got = (*raw_read)(father_out,((char*)ptr)+done,todo-done);
		xbt_assert0(got!=0,"Unexpected end of transmission");
		xbt_assert1(got>0,"Error while reading: %s",strerror(errno));
		done+=got;
	}
}

void father_tell(int kind, const char*fmt,...) _XBT_GNUC_SCANF(2,3);

void father_tell(int kind, const char*fmt,...) {
	int *arg_i;
	double *arg_d;

	/* give syscall number */
	mywrite(e_int,&kind);

	const char *p = fmt;
	va_list ap,ap2;
	va_start(ap, fmt);
	va_copy(ap2,ap);

	/* send stuff to father */
	while (*p) {
		xbt_assert2(*p=='%',"Invalid char in format (%s): expected %%, got %c",fmt,*p);
		p++;
		switch (*p) {
		case 'd':
			arg_i = va_arg(ap, int*);
			mywrite(e_int,arg_i);
			break;
		case 'l':
			p++;
			xbt_assert2(*p=='f',"Invalid char in format (%s): expected %%lf, got %%l%c",fmt,*p);
			arg_d = va_arg(ap, double*);
			mywrite(e_double,arg_d);
			break;
		default:
			xbt_die(bprintf("unimplemented format: %c",*p));
		}
		p++;
	}
	va_end(ap);

	/* get the rewritten version from father */
	p=fmt;
	while (*p) {
		xbt_assert2(*p=='%',"Invalid char in format (%s): expected %%, got %c",fmt,*p);
		p++;
		switch (*p) {
		case 'd':
			arg_i = va_arg(ap2, int*);
			myread(e_int,arg_i);
			break;
		case 'l':
			p++;
			xbt_assert2(*p=='f',"Invalid char in format (%s): expected %%lf, got %%l%c",fmt,*p);
			arg_d = va_arg(ap, double*);
			myread(e_double,arg_d);
			break;
		default:
			xbt_die(bprintf("unimplemented format: %c",*p));
		}
		p++;
	}

	/* sleep by the father's requested time */
	double delay;
	myread(e_double,&delay);
	INFO1("Do sleep %fs",delay);
	if (delay!=0.) xbt_os_sleep(delay);
}

/********************* overloaders *****************************/
int socket(int domain, int type, int protocol)  {
	simterpose_init();

	INFO3("PRE socket(%d,%d,%d)",domain,type,protocol);
	father_tell(e_socket_pre, "%d%d%d", &domain, &type, &protocol);
	int res = (*raw_socket)(domain,type,protocol);
	father_tell(e_socket_post, "%d", &res);

	return res;
}

int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen) {
	simterpose_init();


	INFO2("PRE bind(%d,...,%d)",sockfd,addrlen);
	int res = (*raw_bind)(sockfd,addr,addrlen);
	xbt_die(bprintf("%s() was called. No interposer for that yet",__FUNCTION__));
	return res;
}

int accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen) {
	simterpose_init();

	INFO1("ACCEPT(%d,...,...) CALLED", sockfd);
	int res = (*raw_accept)(sockfd,addr,addrlen);
	xbt_die(bprintf("%s() was called. No interposer for that yet",__FUNCTION__));
	return res;
}

int close(int sock)  {
	simterpose_init();

	int res = (*raw_close)(sock);
	INFO2("CLOSE(%d) WAS CALLED; it returned %d", sock,res);
	xbt_die(bprintf("%s() was called. No interposer for that yet",__FUNCTION__));
	return res;
}
ssize_t write(int sock, const void *buf, size_t size) {
	simterpose_init();

	ssize_t res = (*raw_write)(sock,buf,size);
	INFO4("WRITE(%d,%p,%d) WAS CALLED; it returned %d", sock,buf,size,res);
	xbt_die(bprintf("%s() was called. No interposer for that yet",__FUNCTION__));
	return res;
}
ssize_t send(int sock, const void *buf, size_t size, int flags) {
	simterpose_init();

	ssize_t res = (*raw_send)(sock,buf,size,flags);
	INFO5("SEND(%d,%p,%d,%d) WAS CALLED; it returned %d",
			sock,buf,size,flags,res);
	xbt_die(bprintf("%s() was called. No interposer for that yet",__FUNCTION__));
	return res;
}


ssize_t read(int sock, void *buf, size_t size) {
	simterpose_init();

	xbt_die("read() was called. No interposer for that yet");
}
ssize_t recv(int sock, void *buf, size_t size, int flags) {
	simterpose_init();

	xbt_die("recv() was called. No interposer for that yet");
}

int dup(int sock){
	simterpose_init();

	xbt_die("dup() was called. No interposer for that yet");
}
int dup2(int from, int to){
	simterpose_init();

	xbt_die("dup2() was called. No interposer for that yet");
}
