/*
 * preload-launcher.c: launch childs to follow them by LD_PRELOAD
 *
 * Copyright (C) 2009 simterpose team. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <signal.h>

#include "xbt.h"
#include "simix/simix.h"
#include "preload.h"

XBT_LOG_EXTERNAL_DEFAULT_CATEGORY(simterpose);
static void copy_pipe(const char*msg,int from,int to) {
	int arg_i;
	double arg_f;
	char kind;

	int res = read(from,&kind,sizeof(kind));
   xbt_assert0(res != 0,"Broken pipe (read returned 0)");
	
     
//	fprintf(stderr,"%s: marker: %s...",msg,kind_name(kind));
	write(to,&kind,sizeof(kind));
//	fprintf(stderr,"done\n");
	switch(kind) {
	case e_char:
		res=read(from,&kind,sizeof(kind));
	      xbt_assert0(res != 0,"Broken pipe (read returned 0)");
	   
//	   INFO4("%s (%d->%d): char: %c",msg,from,to,kind);
		fprintf(stderr,"%s (%d->%d): char: '%c' (%d)\n",msg,from,to,kind,kind);
		write(to,&kind,sizeof(kind));
		break;
	case e_int:
	   res=read(from,&arg_i,sizeof(arg_i));
	      xbt_assert0(res != 0,"Broken pipe (read returned 0)");

	   INFO4("%s (%d->%d): int: %d",msg,from,to,arg_i);
//		fprintf(stderr,"%s (%d->%d): int: %d...",msg,from,to,arg_i);
		write(to,&arg_i,sizeof(arg_i));
		break;
	case e_double:
	   res=read(from,&arg_f,sizeof(arg_f));
	   xbt_assert0(res != 0,"Broken pipe (read returned 0)");
	   INFO4("%s (%d->%d): double: %lf",msg,from,to,arg_f);
//		fprintf(stderr,"%s (%d->%d): double: %lf...",msg,from,to,arg_f);
		write(to,&arg_f,sizeof(arg_f));
		break;
	default:
		xbt_die(bprintf("%s: Unknown kind: %c (%d)",msg,kind,kind));
	}
}

/*****************************************************************
 * start a kid in a separate thread (entry point from simix POV) *
 *****************************************************************/
int preload_launch_child(int argc, char* argv[]) {
	int child_in[2];
	int child_out[2];

	child_t child = xbt_new(s_child_t,1);
	child->simdata=MSG_process_self();
	child->name=argv[0];


	/* Launch&setup the child process, setup communication, LD_PRELOAD child */
	if (pipe(child_in) || pipe(child_out)) {
		perror(bprintf("Cannot open the pipes for child %s: ",child->name));
		exit(1);
	}

	child->realpid = fork();
	if (child->realpid==0) { /* child */
		int grand_child_in[2];
		int grand_child_out[2];
		if (pipe(grand_child_in) || pipe(grand_child_out)) {
			perror(bprintf("Cannot open the pipes for grand child %s: ",child->name));
			exit(1);
		}
		int pid = fork();
		if (pid==0) { /* grand-child */

			/* prepare a beautiful argv, with NULL ending pointer (FIXME: should be done in simgrid) */
			int i;
			char **new_argv = malloc(sizeof(char*)*(argc+1)); /* 2*NULL */
			memset(new_argv,0,sizeof(char*)*(argc+1));

			for (i=0;i<argc;i++)
				new_argv[i]=argv[i];
			setenv("LD_PRELOAD","./libsimterposer.so",1);

			/* Setup the pipe to the father */
			close(grand_child_in[1]);
			dup2(grand_child_in[0],20);
			close(grand_child_in[0]);

			close(grand_child_out[0]);
			dup2(grand_child_out[1],21);
			close(grand_child_out[1]);

			/* launch the new process */
			execvp(argv[0], new_argv);
			perror("Cannot exec: ");
			exit(1);
		} else {
#ifdef HAVE_SIMIX_PROCESS_SETNAME
		   SIMIX_process_set_name(SIMIX_process_self(), (char*)"middleman");
#endif
		   
			fprintf(stderr,"grand_child_in[%d;%d] grand_child_out[%d;%d] child_in[%d;%d] child_out[%d;%d]\n",
					grand_child_in[0],grand_child_in[1],grand_child_out[0],grand_child_out[1],
					child_in[0],child_in[1],child_out[0],child_out[1]);
			close(grand_child_in[0]);
			close(grand_child_out[1]);
			close(child_in[1]);
			close(child_out[0]);

			int child_to = grand_child_in[1];
			int child_from = grand_child_out[0];
			int father_to = child_out[1];
			int father_from = child_in[0];

			fd_set rfds;
			int maxfd=(father_to>child_from?father_to:child_from)+1;

			while (1) {
				FD_ZERO(&rfds);
				FD_SET(father_from, &rfds);
				FD_SET(child_from, &rfds);
//				fprintf(stderr,"select(%d,%d)\n",child_from,father_from);
				int retval = select(maxfd, &rfds, NULL, NULL, NULL);
				if (retval == -1)
					perror("select()");
				int found = 0;
				if (FD_ISSET(father_from,&rfds)) {
					copy_pipe("f->c",father_from,child_to);
					found=1;
				}
				if (FD_ISSET(child_from,&rfds)) {
					copy_pipe("c->f",child_from,father_to);
					found=1;
				}
				if (!found){
					xbt_die("Data received on unknown pipe");
				}
			}
		}
	}

	/* father */
	close(child_in[0]);
	close(child_out[1]);

	child->to = child_in[1];
	child->from = child_out[0];

	INFO1("Child %s started",child->name);

	child_discuss(child);
	INFO2("Child %s terminating (%s)",child->name,strerror(errno));
	kill(child->realpid,SIGKILL); /* just to make sure */

	return 0;
}
