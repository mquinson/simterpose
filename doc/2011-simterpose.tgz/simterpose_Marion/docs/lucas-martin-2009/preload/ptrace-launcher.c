/*
 * ptrace-launcher.c: launch childs to follow them by ptrace()
 *
 * Copyright (C) 2009 simterpose team. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <signal.h>

#include "xbt.h"
#include "ptrace.h"
XBT_LOG_EXTERNAL_DEFAULT_CATEGORY(simterpose);

/*****************************************************************
 * start a kid in a separate thread (entry point from simix POV) *
 *****************************************************************/
int ptrace_launch_child(int argc, char* argv[]) {

	INFO1("Launching %s under ptrace analysis",argv[0]);
	/* Met ici le code d'initialisation du ptrace, puis lance le code de suivi (boucle principale d'écoute)*/

	INFO1("Child terminating (%s)",strerror(errno));
	//  kill(child->realpid,SIGKILL); /* just to make sure */
	return 0;
}
