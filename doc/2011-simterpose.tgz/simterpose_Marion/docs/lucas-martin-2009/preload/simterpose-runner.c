/*
 * simterposer-runner.c: runner of guest programs using LD_PRELOAD or ptrace
 *
 * Copyright (C) 2009 simterpose team. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the license (GNU LGPL) which comes with this package.
 */

#define _GNU_SOURCE
#include "config.h"
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <signal.h>

#include <xbt.h>
#include <msg/msg.h>

XBT_LOG_NEW_DEFAULT_CATEGORY(simterpose,"Simterpose emulator messages");

#include "preload.h"
#include "ptrace.h"



/*************************************
 * initialize and run the simulation *
 *************************************/
static void usage(void) {
	fprintf(stderr,
			"Usage: simterpose [-hvV] command ...\n"
			"\t-p file      specify the platform file to use (platform.xml by default)\n"
			"\t-d file      specify the deployment file to use (basic.xml by default)\n\n"
			"\t-h           Help (this)\n"
			"\t-v           Increase verbosity level\n"
			"\t-V           Print simterpose version\n");

	exit(1);
}

int verbose = 0;

#define PRELOAD 1
#define PTRACE 2

int main(int argc, char *argv[]) {
	const char *platform_file = "platform.xml";
	const char *deployment_file = "basic.xml";

	MSG_global_init(&argc,argv);

	int opt;
	int intercepter = PRELOAD;
	while ((opt = getopt(argc, argv, "hvVp:d:tl")) != -1)
		switch (opt) {
		case 'p':
			platform_file=optarg;
			break;
		case 'd':
			deployment_file=optarg;
			break;
		case 'v':
			verbose++;
			break;
		case 'V':
			printf("simterpose LD_PRELOAD runner (version " VERSION ")");
			break;
		case 't':
			intercepter = PTRACE;
			break;
		case 'l':
			intercepter = PRELOAD;
			break;
		case 'h':
		default:
			usage();
		}

	argc -= optind;
	argv += optind;

	if (argc > 0)
		usage();

	/* Start the MSG simulation */
	MSG_error_t res = MSG_OK;

	switch (intercepter) {
	case PRELOAD:
		MSG_function_register_default(preload_launch_child);
		break;
	case PTRACE:
		MSG_function_register_default(ptrace_launch_child);
		break;
	default:
		xbt_die(bprintf("Unknown intercepter (%d)", intercepter));
	}

	MSG_create_environment(platform_file);
	MSG_launch_application(deployment_file);

	res = MSG_main();
	INFO1("Simulation time %g",MSG_get_clock());
	MSG_clean();

	if(res==MSG_OK)
		return 0;
	else
		return 1;
}
