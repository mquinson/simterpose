/**********************************************************************/
/*                                                                    */
/* The client part of a client-server pair. This simply takes two     */
/* numbers and adds them together, returning the result to the client */
/*                                                                    */
/* User types:                                                        */
/*                   3 + 5                                            */
/*                   a + b                                            */
/*                   halt + server                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>


#define PORT 4242           /* define a port number for the service */
//#define HOST "Fafard"
#define HOST "127.0.0.1"
#define bufsize 20

/**********************************************************************/
/* Main                                                               */
/**********************************************************************/

int main (int argc,char *argv[]){
  struct sockaddr_in cin; 
  struct hostent *hp;
  char buffer[bufsize];
  int sd;

  printf("client: starting\n");
  sleep(1); /* wait for server */
  
  /* Either by hostname ........ lookup in DNS */
  
  if ((hp = gethostbyname(HOST)) == NULL) {
    perror("client: gethostbyname: ");
    exit(1);
  }
  
  memset(&cin,0,sizeof(cin));
  
  cin.sin_family = AF_INET;
  cin.sin_addr.s_addr = ((struct in_addr *)(hp->h_addr))->s_addr;
  cin.sin_port = htons(PORT);
    
  printf("client: Trying to connect to %s  = %s\n",
	 HOST,inet_ntoa(cin.sin_addr));
  
  if ((sd = socket(AF_INET,SOCK_STREAM,0)) == -1) {
    perror("client: socket");
    exit(1);
  }
  
  if (connect(sd,(void *)&cin,sizeof(cin)) == -1) {
    perror("client: connect");
    exit(1);
  }

  sprintf(buffer,"%d + %d",1,2);//argv[1],argv[3]);
  
  if (send(sd,buffer,strlen(buffer)+1,0) == -1) {
    perror ("client: send");
    exit(1);
  }

  if (recv(sd,buffer,bufsize,0) == -1) {
    perror("client: recv");
    exit (1);
  }
  
  printf ("client: Server responded with %s\n",buffer);
  
  close (sd);

  return 0;
}


