/**********************************************************************/
/*                                                                    */
/* The server part of a client-server pair. This simply takes two     */
/* numbers and adds them together, returning the result to the client */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define bufsize 20

static int DoService(char *buffer) {
  int a=0,b=0;
  
  printf("server: Received: %s\n",buffer);
  sscanf(buffer,"%d + %d\n",&a,&b);

  if (a>0 && b>0) {
    sprintf(buffer,"%d + %d = %d",a,b,a+b);
    return 1;
  } else {
    if (strncmp("halt",buffer,4) == 0) {
      sprintf(buffer,"Server closing down!");
      return 0;
    } else {
      sprintf(buffer,"Invalid protocol");
      return 1;
    }
  }
}

int main () {
  struct sockaddr_in server_in;
  socklen_t server_in_len = sizeof(server_in);

  char buffer[bufsize];
  int sd, sd_client;

  fprintf(stderr,"server: starting (LD_PRELOAD=%s)\n",getenv("LD_PRELOAD"));
  alarm(30); /* quit in 30 secs automatically */

  if ((sd = socket(AF_INET,SOCK_STREAM,0)) < 0) {
    perror("server: socket");
    exit(1);
  }
  
  int on = 1;
  if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on))) {
    close(sd);
    perror("server: setsockopt");
    exit(1);
  }


  server_in.sin_port = htons((u_short)4242);
  server_in.sin_addr.s_addr = INADDR_ANY;
  server_in.sin_family = AF_INET;
  
  if (bind(sd,(struct sockaddr *)&server_in,server_in_len) < 0) {
    close(sd);
    perror("server: bind");
    exit(1);
  }
  
  if (listen(sd,5) < 0) {
    close(sd);
    perror("server: listen");
    exit(1);
  }

  fprintf(stderr, "server: let's accept\n");
  if ((sd_client = accept(sd,(struct sockaddr *)&server_in,&server_in_len)) < 0) {
    close(sd);
    perror("server: accept");
    exit(1);
  }
  
  if (recv(sd_client,buffer,sizeof(buffer),0) < 0) {      
    close(sd);
    perror("server: recv");
    exit(1);
  }
  
  if (DoService(buffer)) {

    if (send(sd_client,buffer,strlen(buffer)+1,0) < 0) {
      close(sd);
      perror("server: send");
      exit(1);
    }
  }
  
  close (sd_client);

  /* shuthing server down after request */
  close (sd);
  printf("server: closing down...\n");
  return 0;
}


