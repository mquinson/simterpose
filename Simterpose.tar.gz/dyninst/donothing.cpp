#include <stdio.h>
#include <fcntl.h>
#include "BPatch.h"
#include "BPatch_process.h"
#include "BPatch_function.h"
#include "BPatch_Vector.h"
#include "BPatch_thread.h"

void usage(){
  fprintf(stderr,"Usage : essai <filename> <args>\n");
}

BPatch bpatch;


int main(int argc, char *argv[]){


  if(argc<2){
    usage();
    exit(1);
  }

  fprintf(stderr,"Attaching to process ... \n");
  BPatch_process *appProc = bpatch.processCreate(argv[1],(const char**)&argv[1]);

  if(!appProc){
    fprintf(stderr, "echec create process\n");
    return -1;
  }

  BPatch_image *appImage;

  BPatch_Vector<BPatch_function *> dupFuncs;
  BPatch_Vector<BPatch_point *> *points;

  fprintf(stderr, "Opening the programm image ...\n");

  appImage = appProc->getImage();

  appImage->findFunction("free",dupFuncs);

  if(dupFuncs.size() == 0){
    fprintf(stderr, "ERROR : Unable to find function for dup()\n");
    return 1;
  }else{
    printf("dup trouvé !\n");
  }

points = dupFuncs[0]->findPoint(BPatch_entry);

BPatch_variableExpr *intCounter = appProc->malloc(*appImage->findType("int"));
int n;
 n = 42;
if (!intCounter->writeValue(&n)) {
printf("writeValue failed\n");
}

BPatch_arithExpr addOne(BPatch_assign, *intCounter, BPatch_arithExpr(BPatch_plus, *intCounter, BPatch_constExpr(1)));

appProc->insertSnippet(addOne, *points);

intCounter->readValue(&n);
printf("n=%d\n", n);
  printf("before cont.\n");

  appProc->continueExecution();

  printf("cont.\n");

  while (!appProc->isTerminated()) {
     bpatch.waitForStatusChange();
     intCounter->readValue(&n);
     printf("n=%d\n", n);
  }
  printf("done.\n");
intCounter->readValue(&n);
printf("n=%d\n", n);
}
