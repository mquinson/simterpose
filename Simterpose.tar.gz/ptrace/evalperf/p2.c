#include "trace.h"

int main(int argc, char *argv[]){   
  
  pid_t tracedpid;
  long eax;
  int status;
  int syscalls_in[NB_SYSCALLS];
  int stoppedpid;
  int domain;
  int n = 0;

  struct user_regs_struct regs;
  char *application=argv[1];

  //init tab
  int i;
  for(i=0;i<NB_SYSCALLS;i++){
    syscalls_in[i]=0;
  }
  
  tracedpid = fork();
  
  if(tracedpid == 0) {
    
    if (ptrace(PTRACE_TRACEME, 0, NULL, NULL)==-1) {
      perror("ptrace traceme");
      exit(1);
    }
    if (execl(application, application, NULL)==-1) {
      perror("execl");
      exit(1);
    }
  
  }else {

    // We wait for the child to be blocked by ptrace in the first exec()
    wait(&status);

    // Resume the child
    if (ptrace(PTRACE_SYSCALL, tracedpid, 0, 0)==-1) {
      perror("ptrace syscall");
      exit(1);
    }
	  
    while(1) {
      // __WALL to follow all children
      stoppedpid = waitpid(-1, &status, __WALL);
      if (stoppedpid == -1) {
	printf("n: %d\n", n); 
	perror("wait");
	exit(1);
      }

      if(WIFEXITED(status)){
        printf("[%d] le fils est mort\n",stoppedpid);
	continue;
      }
      
      if (ptrace(PTRACE_GETREGS, stoppedpid,NULL, &regs)==-1) {
	perror("ptrace getregs");
	exit(1);
	}
      if (regs.orig_eax == SYS_getuid32)
	n++;

      /*switch(regs.orig_eax){
      case SYS_write:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	  int len=(int)regs.edx;
	  char data[len];
	  getdata(stoppedpid, (void*)regs.ecx, data, (size_t) regs.edx);
	  printf("[%d] write(%ld,\"%s\", %d) = %ld\n",stoppedpid,regs.ebx,data,(int)regs.edx, eax);
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  int len=(int)regs.edx;
	  char data[len];
	  getdata(stoppedpid, (void*)regs.ecx, data, (size_t) regs.edx);
	  printf("[%d] write(%ld,\"%s\", %d) = %ld\n",stoppedpid,regs.ebx,data,(int)regs.edx, eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_read:
	if(syscalls_in[regs.orig_eax] == 0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  int len=(int)regs.edx;
	  char buff[len];
	  getdata(stoppedpid,(void *)regs.ecx, buff,len);
	  printf("[%d] read(%ld,%s, %ld) = %ld\n",stoppedpid, regs.ebx,buff,regs.edx, eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_fork:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  printf("[%d] fork = %ld\n", stoppedpid,eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS__newselect:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  getArgsSelect(stoppedpid,&regs);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_poll:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  getArgsPoll(stoppedpid,(void *)regs.ebx, (nfds_t)regs.ecx);
	  printf("%d \n",(int)eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_open:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  char data[BUFFER_SIZE];
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  getdata(stoppedpid,(void *)regs.ebx,data,BUFFER_SIZE);
	 
	  char *flags;
	  switch(regs.ecx){
	  case 0 :
	    flags=malloc(9);
	    strcpy(flags,"O_RDONLY");
	    break;
	  case 1 :
	    flags=malloc(9);
	    strcpy(flags,"O_WRONLY");
	    break;
	  case 2 :
	    flags=malloc(7);
	    strcpy(flags,"O_RDWR");
	    break;
	  }
	  if(strlen(flags)>0)
	    printf("[%d] open(\"%s\", %s) = %ld\n",stoppedpid,data,flags, eax);
	  else
	    printf("[%d] open(\"%s\", %ld) = %ld\n",stoppedpid,data,regs.ecx, eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_clone:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	  printf("[%d] enter clone() = %ld\n",stoppedpid,eax);
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  printf("[%d] clone() = %ld\n",stoppedpid,eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_close:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  printf("[%d] close(%ld) = %ld\n",stoppedpid,regs.ebx,eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_dup:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	  printf("[%d] enter dup(%ld) = %ld\n",stoppedpid,regs.ebx, eax);
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  printf("[%d] dup(%ld) = %ld\n",stoppedpid,regs.ebx, eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_dup2:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  printf("[%d] dup2(%ld, %ld) = %ld\n",stoppedpid,regs.ebx,regs.ecx, eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      case SYS_exit_group:
	printf("[%d] exit(%ld) called \n",stoppedpid,regs.ebx);
	break;

      case SYS_exit:
	printf("[%d] exit(%ld) called \n",stoppedpid,regs.ebx);
	break;

      case SYS_socketcall:
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  switch(regs.ebx){
	  case 1:
	    printf("[%d] socket( ",stoppedpid);
	    domain=getArgsSocket(stoppedpid,(void *)regs.ecx);
	    printf(" ) = %ld\n",eax);
	    break;

	  case 2:
	    printf("[%d] bind( ",stoppedpid);
	    getArgsBindAccept(stoppedpid,(void *)regs.ecx,domain,0);
	    printf(" ) = %ld\n",eax);
	    break;

	  case 4: 
	    printf("[%d] listen( ", stoppedpid); 
	    getArgsListen(stoppedpid,(void *)regs.ecx);
	    printf(" ) = %ld\n", eax);
	    break;

	  case 5:
	    printf("[%d] accept( ",stoppedpid);
	    getArgsBindAccept(stoppedpid,(void *)regs.ecx,domain,1);
	    printf(" ) = %ld\n",eax);
	    break;

	  case 9:
	    printf("[%d] send( ",stoppedpid);
	    getArgsSendRecv(stoppedpid,(void *)regs.ecx);
	    printf(" ) = %ld\n",eax);
	    break;

	  case 10:
	    printf("[%d] recv( ",stoppedpid);
	    getArgsSendRecv(stoppedpid,(void *)regs.ecx);
	    printf(" ) = %ld\n",eax);
	    break;

	  case 11:
	    printf("[%d] sendto(",stoppedpid);
	    getArgsSendTo(stoppedpid, (void *)regs.ecx);
	    printf(" ) = %ld\n", eax);
	    break;

	  case 12:
	    printf("[%d] recvfrom(",stoppedpid);
	    getArgsRecvFrom(stoppedpid, (void *)regs.ecx);
	    printf(" ) = %ld\n", eax);
	    break;

	  case 13:
	    printf("shutdown\n");
	    break;

	  case 14:
	    printf("[%d] setsockopt(",stoppedpid);
	    getArgsSetsockopt(stoppedpid, (void *)regs.ecx);
	    printf("%d\n",(int)eax);
	    break;

	  case 15:
	    printf("[%d] getsockopt(",stoppedpid);
	    getArgsGetsockopt(stoppedpid, (void *)regs.ecx);
	    printf("%d\n",(int)eax);
	    break;
	  }
	  
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

      default :
	if(syscalls_in[regs.orig_eax]==0) {
	  syscalls_in[regs.orig_eax]=1;
	}else { 
	  eax = ptrace(PTRACE_PEEKUSER, stoppedpid, 4 * EAX, NULL);
	  printf("[%d] Unknown syscall %ld = %ld\n", stoppedpid,regs.orig_eax,eax);
	  syscalls_in[regs.orig_eax]=0;
	}
	break;

	}

	}*/
      //printf("Avant ptrace syscall\n");
      if (ptrace(PTRACE_SYSCALL, stoppedpid, NULL, NULL)==-1) {
	perror("ptrace syscall");
	exit(1);
      }
      //printf("Après ptrace syscall\n");
    }
  }
  return 0;
}
