#include <unistd.h>
#include <time.h>
#include <sys/time.h>

/* origin: glibc manual */
/**
 * this function is for computing the time difference between timeval x and y
 * the result is stored in result
 */
int timeval_substract(struct timeval *result, struct timeval *x, struct timeval *y)
{
        /* perform the carry for the later subtraction by updating y. */
        if (x->tv_usec < y->tv_usec) {
                int nsec = (y->tv_usec - x->tv_usec) / 1000000 + 1;
                y->tv_usec -= 1000000 * nsec;
                y->tv_sec += nsec;
        }
        if (x->tv_usec - y->tv_usec > 1000000) {
                int nsec = (x->tv_usec - y->tv_usec) / 1000000;
                y->tv_usec += 1000000 * nsec;
                y->tv_sec -= nsec;
        }

        /* compute the time remaining to wait.
           tv_usec is certainly positive. */
        result->tv_sec = x->tv_sec - y->tv_sec;
        result->tv_usec = x->tv_usec - y->tv_usec;

        /* return 1 if result is negative. */
        return x->tv_sec < y->tv_sec;
}


int main(){
  
  struct timeval tstart;
  struct timeval tstop;
  struct timeval tres;
  double elapsed;
  
  gettimeofday(&tstart, NULL);

  int i;
  for(i=0;i<1000000;i++){
    getuid();
  }

  gettimeofday(&tstop, NULL);
  timeval_substract(&tres, &tstop, &tstart);
  elapsed = tres.tv_sec + ((double) tres.tv_usec) / 1000000;
  printf("%f\n", elapsed);

}
