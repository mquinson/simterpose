#include "wrap.h"
#include "fonctions.h"

#define RTLD_NEXT ((void *) -1l)

char *error_msg;


void LogWrap(char *mess){
  FILE *file_log=fopen("/home/marion/simterpose/valgrind/file_log","a");
  fprintf(file_log,"%s",mess);
  fclose(file_log);
}

void DLSym_fonctions(){

  socket_orig=dlsym(RTLD_NEXT,"socket");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym socket !\n");
  
  close_orig=dlsym(RTLD_NEXT,"close");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym close !\n");

  listen_orig=dlsym(RTLD_NEXT,"listen");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym listen !\n");

  accept_orig=dlsym(RTLD_NEXT,"accept");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym accept !\n");
  
  bind_orig=dlsym(RTLD_NEXT,"bind");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym bind !\n");

  send_orig=dlsym(RTLD_NEXT,"send");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym send !\n");

  sendto_orig=dlsym(RTLD_NEXT,"sendto");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym sendto !\n");

  recv_orig=dlsym(RTLD_NEXT,"recv"); 
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym recv !\n");

  recvfrom_orig=dlsym(RTLD_NEXT,"recvfrom");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym recvfrom !\n");

  connect_orig=dlsym(RTLD_NEXT,"connect");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym connect !\n");

  select_orig=dlsym(RTLD_NEXT,"select");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym select !\n");

  read_orig=dlsym(RTLD_NEXT,"read");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym read !\n");
  
  write_orig=dlsym(RTLD_NEXT,"write");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym write !\n");

  pthread_create_orig=dlsym(RTLD_NEXT,"pthread_create");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym pthread_create !\n");

  pthread_join_orig=dlsym(RTLD_NEXT,"pthread_join");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym pthread_join !\n");

  pthread_exit_orig=dlsym(RTLD_NEXT,"pthread_exit");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym pthread_exit !\n");

  dup_orig=dlsym(RTLD_NEXT,"dup");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym dup !\n");

  dup2_orig=dlsym(RTLD_NEXT,"dup2");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym dup2 !\n");

  fork_orig=dlsym(RTLD_NEXT,"fork");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym fork !\n");

  setuid_orig=dlsym(RTLD_NEXT,"setuid");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym setuid !\n");
  
  system_orig=dlsym(RTLD_NEXT,"system");
  if((error_msg=dlerror())!=NULL)
    fprintf(stderr,"Erreur dlsym system !\n");

}


int socket(int domain, int type, int protocol){
  DLSym_fonctions();
  LogWrap("appel socket()\n");
  int ret=socket_orig(domain,type,protocol);
  LogWrap("appel socket() terminé\n");
  return ret;
}

int close(int fd){
  DLSym_fonctions();
  LogWrap("appel close()\n");
  int ret=close_orig(fd);
  LogWrap("appel close() terminé\n");
  return ret;
}

ssize_t send(int s, const void*msg, size_t len, int flags){
  DLSym_fonctions();
  LogWrap("appel send()\n");
  ssize_t ret=send_orig(s, msg, len, flags);
  LogWrap("appel send() terminé\n");
  return ret;
}

ssize_t sendto(int s, const void *msg, size_t len, int flags, const struct sockaddr *to, socklen_t tolen){
  DLSym_fonctions();
  LogWrap("appel sendto()\n");
  ssize_t ret=sendto_orig(s,msg,len,flags,to,tolen);
  LogWrap("appel sendto() terminé\n");
  return ret;
}

ssize_t recv(int s, void *buf, size_t len, int flags){
  DLSym_fonctions();
  LogWrap("appel recv()\n");
  ssize_t ret=recv_orig(s, buf, len, flags);
  LogWrap("appel recv() terminé\n");
  return ret;
}

ssize_t recvfrom(int s, void *buf, size_t len, int flags, struct sockaddr *from, socklen_t *fromlen){
  DLSym_fonctions();
  LogWrap("appel recvfrom()\n");
  ssize_t ret=recvfrom_orig(s, buf, len, flags, from,fromlen);
  LogWrap("appel recvfrom() terminé\n");
  return ret;
}

int bind(int sockfd,const struct sockaddr *my_addr, socklen_t addrlen){
  DLSym_fonctions();
  LogWrap("appel bind()\n");
  int ret=bind_orig(sockfd, my_addr, addrlen);
  LogWrap("appel bind() terminé\n");
  return ret;
}

int connect(int sockfd, const struct sockaddr *serv_addr, socklen_t addrlen){
  DLSym_fonctions();
  LogWrap("appel connect()\n");
  int ret=connect_orig(sockfd, serv_addr, addrlen);
  LogWrap("appel connect() terminé\n");
  return ret;
}

int listen(int s, int backlog){
  DLSym_fonctions();
  LogWrap("appel listen()\n");
  int ret=listen_orig(s,backlog);
  LogWrap("appel listen() terminé\n");
  return ret;
}

int accept(int sock, struct sockaddr *adresse, socklen_t *longueur){
  DLSym_fonctions();
  LogWrap("appel accept()\n");
  int ret=accept_orig(sock,adresse, longueur);
  LogWrap("appel accept() terminé\n");
  return ret;
}

int select(int n, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *timeout){
  DLSym_fonctions();
  LogWrap("appel select()\n");
  int ret=select_orig(n,readfds,writefds,exceptfds,timeout);
  LogWrap("appel select() terminé\n");
  return ret;
}

int read(int fildes, void *buf, size_t nbyte){
  DLSym_fonctions();
  LogWrap("appel read()\n");
  int ret=read_orig(fildes,buf,nbyte);
  LogWrap("appel read() terminé\n");
  return ret;
}

int write(int handle, const void *buf, size_t nbyte){
  DLSym_fonctions();
  LogWrap("appel write()\n");
  int ret=write_orig(handle,buf,nbyte);
  LogWrap("appel write() terminé\n");
  return ret;
}

int pthread_create(pthread_t* thread, const pthread_attr_t* attr, void*(*start_routine)(void*), void* arg){
  DLSym_fonctions();
  LogWrap("appel pthread_create()\n");
  int ret=pthread_create_orig(thread, attr, start_routine, arg);
  LogWrap("appel pthread_create() terminé\n");
  return ret;
}

int pthread_join(pthread_t thread, void **thread_return){
  DLSym_fonctions();
  LogWrap("appel pthread_join()\n");
  int ret=pthread_join_orig(thread, thread_return);
  LogWrap("appel pthread_join() terminé\n");
  return ret;
}

void __attribute__((noreturn)) pthread_exit(void *retval){
  DLSym_fonctions();
  LogWrap("appel pthread_exit()\n");
  pthread_exit_orig(retval);
  LogWrap("appel pthread_exit() terminé\n");
}

int dup(int oldfd){
  DLSym_fonctions();
  LogWrap("appel dup()\n");
  int ret=dup_orig(oldfd);
  LogWrap("appel dup() terminé\n");
  return ret;
}

int dup2(int oldfd, int newfd){
  DLSym_fonctions();
  LogWrap("appel dup2()\n");
  int ret=dup2_orig(oldfd,newfd);
  LogWrap("appel dup2() terminé\n");
  return ret;
}

pid_t fork(void){
  DLSym_fonctions();
  LogWrap("appel fork()\n");
  pid_t ret=fork_orig();
  LogWrap("appel fork() terminé\n");
  return ret;
}

int setuid(uid_t uid){
  DLSym_fonctions();
  LogWrap("appel setuid()\n");
  int ret=setuid_orig(uid);
  LogWrap("appel setuid() terminé\n");
  return ret;
}

int system(const char * string){
  DLSym_fonctions();
  LogWrap("appel system()\n");
  int ret=system_orig(string);
  LogWrap("appel system() terminé\n");
  return ret;
}
