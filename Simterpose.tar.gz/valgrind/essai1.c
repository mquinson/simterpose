#include "include/valgrind.h"
#include <stdio.h>


int I_WRAP_SONAME_FNNAME_ZZ(libcZdsoZd6, dup)(int n){

  int ret;
  OrigFn fn;
  VALGRIND_GET_ORIG_FN(fn); // on recupere l'adresse de la fonction dup originale
  printf("wrapper-pre : dup(%d)\n",n);
  CALL_FN_W_W(ret,fn,n); // on execute la fonction dup avec ses parametres et on stocke le resultat dans ret
  printf("wrapper-post : dup(%d) = %d \n",ret,n);
  return ret;
}

int main(){

  dup(0);

}
